#include <stdio.h>
#include "module2.h"

void f2(void) {
    printf("f2 called\n");
}
