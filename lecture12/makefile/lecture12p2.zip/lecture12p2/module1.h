#ifndef MODULE1_H
#define MODULE1_H

void f1(void);

#endif /* MODULE1_H */
